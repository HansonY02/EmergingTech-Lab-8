# Testing and revision

The preserved 0.1 primary and clinical responses separated the applications but used generic triggers such as “Monitor vendor progress and hospital deployment evidence.” That was a substantive operational weakness, despite valid JSON. The revision changed only specialist instructions and metadata, then reran the original cases with the same technology and organizational facts. Version 0.2 requires an owner, cadence, observable trigger, follow-up action and a dated expiry condition. The evidence packet was embedded for reproducibility. No case was altered to make the result easier; only source context was appended.

agents/landscape_agent/responses/contrast_1_response.json: VALIDATION PASSED; full JSON Schema PASS
agents/landscape_agent/responses/contrast_2_response.json: VALIDATION PASSED; full JSON Schema PASS
agents/landscape_agent/responses/primary_response.json: VALIDATION PASSED; full JSON Schema PASS
agents/landscape_agent/records/baseline_v0_1/contrast_1_response.json: VALIDATION PASSED; full JSON Schema PASS
agents/landscape_agent/records/baseline_v0_1/primary_response.json: VALIDATION PASSED; full JSON Schema PASS
FROZEN CORE INTACT
All three input cases: JSON Schema PASS
General ET finding identical across final cases: PASS
Application and recommendation distinguish all contexts: PASS
All final triggers identify owners; each case has an expiry condition: PASS
All original scaffold files byte-identical to original ZIP: PASS
Original ZIP SHA256: 3875e8924556b2801c572390fb2c90e5957aea452d33312a31084e1f3712e754
Runtime: ChatGPT/Codex interactive analysis; no API or separate automated model call. JSON responses saved by local scripts.
Validation checks structure and selected consistency rules; does not prove factual accuracy, clinical safety or autonomous execution.
