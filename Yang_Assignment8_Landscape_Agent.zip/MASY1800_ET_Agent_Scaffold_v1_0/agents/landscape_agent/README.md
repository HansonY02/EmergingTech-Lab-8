# Emerging Technology Landscape Agent

Specialist version 0.2. Primary: hospital supply transport. Contrasts: autonomous treatment and warehouse picking. Run course build_prompt.py and validate_response.py from the scaffold root. Sources and limitations are in records/evidence_register.json. Read records/validation_log.txt and records/agent_record.md. No API key is needed.
